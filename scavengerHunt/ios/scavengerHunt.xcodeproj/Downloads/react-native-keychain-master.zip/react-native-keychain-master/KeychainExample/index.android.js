import { AppRegistry } from 'react-native';
import KeychainExample from './app';

AppRegistry.registerComponent('KeychainExample', () => KeychainExample);
